node.default['tempVar']='template variable'
