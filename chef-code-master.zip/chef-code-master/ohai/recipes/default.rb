#ohai_plugin 'product plugin' do
#  name 'myproduct_ohai_vars'
#  resource :template
#end

